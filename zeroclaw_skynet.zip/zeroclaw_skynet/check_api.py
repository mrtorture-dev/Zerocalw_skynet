import asyncio
import aiohttp

async def check_api():
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    # Probamos el endpoint de la API principal, no el de la UI
    url = "https://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8"
    
    headers = {
        "Authorization": f"Bearer {token}",
        "Content-Type": "application/json"
    }
    
    async with aiohttp.ClientSession() as session:
        print(f"Probando API GET a {url}")
        async with session.get(url, headers=headers) as resp:
            print(f"Status: {resp.status}")
            text = await resp.text()
            print(f"Response: {text}")

if __name__ == "__main__":
    asyncio.run(check_api())
