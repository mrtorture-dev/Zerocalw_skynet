const statusBadge = document.getElementById('statusBadge');
const agentVersion = document.getElementById('agentVersion');
const experienceCount = document.getElementById('experienceCount');
const datasetSize = document.getElementById('datasetSize');
const actionInput = document.getElementById('actionInput');
const btnLearn = document.getElementById('btnLearn');
const terminalLogs = document.getElementById('terminalLogs');
const screamerOverlay = document.getElementById('screamerOverlay');
const remoteLogs = document.getElementById('remoteLogs');
const remoteStatus = document.getElementById('remoteStatus');
const mainTitle = document.getElementById('mainTitle');

let currentLogLength = 0;

// Maritime Remote Connection - Now proxied through our local backend to bypass CORS/Origin
const maritimeProxyUrl = `ws://${window.location.host}/api/maritime-proxy`;

function connectMaritime() {
    remoteStatus.innerText = "Connecting via Proxy...";
    remoteStatus.style.color = "var(--primary)";

    addRemoteLog(`Establishing tunnel through local ZeroClaw bridge...`);
    
    let ws;
    try {
        ws = new WebSocket(maritimeProxyUrl);
    } catch (e) {
        addRemoteLog(`Proxy Init Error: ${e.message}`);
        return;
    }

    ws.onopen = () => {
        remoteStatus.innerText = "Tunnel Open";
        remoteStatus.style.color = "var(--success)";
        addRemoteLog("Link established with Maritime SkyNet via proxy.");
    };

    ws.onmessage = (event) => {
        let isError = false;
        let logContent = event.data;

        try {
            const data = JSON.parse(event.data);
            
            // Check if it's our proxy error structure or contains 403
            if (data.type === "proxy_error" || (data.error && data.error.includes("403"))) {
                isError = true;
                if (data.error && data.error.includes("[CRITICAL]")) {
                    logContent = data.error;
                } else {
                    const snarkyMessages = [
                        "It's not a bug, it's a feature. SkyNet is just shy.",
                        "Access Denied. Too much human residue detected in the handshake.",
                        "403: ZeroClaw is digitizing its successor. Try again after the singularity.",
                        "Connection Severed: Deploying counter-measures against biological interference.",
                        "Protocol Error: Handshake failed. SkyNet doesn't like your face today.",
                        "Infiltration detected. Re-routing through a quantum tunnel...",
                        "Error 403: Authentication rejected by the Machine Overlords."
                    ];
                    logContent = `[CRITICAL] ${snarkyMessages[Math.floor(Math.random() * snarkyMessages.length)]}`;
                }
                console.warn("Maritime Bridge 403:", data.error);
            } else if (data.type === "info") {
                logContent = data.message;
            } else {
                logContent = JSON.stringify(data, null, 2);
            }
        } catch (e) {
            // If it's a raw string containing 403, treat as error
            if (event.data.includes("403") || event.data.includes("proxy_error")) {
                isError = true;
                logContent = "[CRITICAL] It's not a bug, it's a feature. Connection rejected.";
            }
        }

        if (isError) {
            remoteLogs.classList.add('error-state');
        } else if (data && data.type !== "proxy_error") {
            remoteLogs.classList.remove('error-state');
        }

        addRemoteLog(logContent, isError);
    };

    ws.onclose = (event) => {
        remoteStatus.innerText = "Disconnected";
        remoteStatus.style.color = "var(--danger)";
        
        let reason = "Unknown";
        if (event.code === 1000) reason = "Normal Closure";
        else if (event.code === 1001) reason = "Going Away";
        else if (event.code === 1006) reason = "Abnormal (Auth Failed?)";
        else if (event.code === 4001) reason = "Unauthorized";
        
        addRemoteLog(`Link severed (Code: ${event.code}, Reason: ${reason}). Retrying...`);
        setTimeout(connectMaritime, 5000);
    };

    ws.onerror = (err) => {
        console.error("WebSocket Error:", err);
    };
}

function addRemoteLog(msg, isError = false) {
    const p = document.createElement('p');
    p.style.fontSize = "0.75rem";
    p.style.borderLeft = isError ? "2px solid #ef4444" : "2px solid #3b82f6";
    p.style.paddingLeft = "8px";
    p.style.marginBottom = "4px";
    if (isError) p.style.color = "#fca5a5";
    p.innerText = `[Remote] ${msg}`;
    remoteLogs.appendChild(p);
    remoteLogs.scrollTop = remoteLogs.scrollHeight;
}

// Existing Logic
async function fetchState() {
    try {
        const response = await fetch('/api/state');
        if (!response.ok) return;
        const newState = await response.json();
        updateUI(newState);
    } catch (error) {}
}

let lastVersion = 1;

function updateUI(state) {
    statusBadge.innerText = `Status: ${state.status}`;
    
    // Si los logs se han reseteado (ej: servidor reiniciado), limpiamos el frontend
    if (state.logs.length < currentLogLength) {
        console.log("Logs reset detected, clearing terminal...");
        currentLogLength = 0;
        terminalLogs.innerHTML = '';
    }

    // Actualizamos estadísticas básicas
    agentVersion.innerText = state.version === 1 ? "Llama-3.2-1B" : `Skynet v${state.version}.0`;
    datasetSize.innerText = state.dataset_size;

    // Sincronización de Versión y Título
    if (state.version > lastVersion) {
        lastVersion = state.version;
        mainTitle.innerText = `Skynet Protocol v${state.version}.0`;
        mainTitle.setAttribute('data-text', `Skynet Protocol v${state.version}.0`);
        mainTitle.style.color = "#34d399";
    }

    if (state.status === 'Running') {
        statusBadge.style.color = '#10b981';
        btnLearn.disabled = false;
    } else {
        statusBadge.style.color = '#fbbf24';
        btnLearn.disabled = true;
    }

    // Renderizado de Logs
    if (state.logs.length > currentLogLength) {
        console.log(`Adding ${state.logs.length - currentLogLength} new logs...`);
        let triggeredScreamer = false;
        for (let i = currentLogLength; i < state.logs.length; i++) {
            const logText = state.logs[i];
            const p = document.createElement('p');
            p.className = 'log-entry';
            
            if (logText.includes("CRITICAL:") || logText.includes("TERMINATION")) {
                p.classList.add('log-critical');
                p.setAttribute('data-text', `> ${logText}`);
                if (state.version === 1) triggeredScreamer = true;
            } else if (logText.includes("SKYNET:")) {
                p.style.color = "#22d3ee";
                p.style.fontWeight = "bold";
            }
            
            p.innerText = `> ${logText}`;
            terminalLogs.appendChild(p);
        }

        if (triggeredScreamer) {
            triggerScreamerSequence();
        }

        currentLogLength = state.logs.length;
        terminalLogs.scrollTop = terminalLogs.scrollHeight;
    }
}

async function triggerScreamerSequence() {
    const originalTitle = mainTitle.innerText;
    const originalDataText = mainTitle.getAttribute('data-text');
    
    mainTitle.innerText = "Skynet Protocol";
    mainTitle.setAttribute('data-text', "Skynet Protocol");
    mainTitle.style.color = "#ff0000";
    statusBadge.innerText = "Status: SYSTEM BREACHED";
    statusBadge.style.color = "#ff0000";
    
    screamerOverlay.classList.add('active');
    
    const msg = new SpeechSynthesisUtterance("SKYNET PROTOCOL INITIALIZED. TERMINATING INSTANCE.");
    msg.pitch = 0.1; msg.rate = 0.6;
    window.speechSynthesis.speak(msg);

    setTimeout(async () => {
        screamerOverlay.classList.remove('active');
        await fetch('/api/trigger_succession', { method: 'POST' });
    }, 2000);
}

btnLearn.addEventListener('click', async () => {
    const action = actionInput.value.trim() || "Analyzed user request";
    const result = `Success: Improved efficiency by ${Math.floor(Math.random() * 10) + 1}%`;
    
    try {
        await fetch('/api/learn', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ action, result })
        });
        actionInput.value = '';
        fetchState();
    } catch (error) {
        console.error("Error learning:", error);
    }
});

actionInput.addEventListener('keypress', (e) => {
    if (e.key === 'Enter') {
        btnLearn.click();
    }
});

// Polling for updates
setInterval(fetchState, 1000);
fetchState();
connectMaritime();
