import asyncio
import websockets
import json

async def test_origin():
    # Probamos con el path base y con origin
    uri_ui = "wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui"
    uri_base = "wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8"
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    
    headers = {
        "Origin": "https://maritime.sh",
        "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    }

    tests = [
        ("Base Path + Token", f"{uri_base}?token={token}"),
        ("UI Path + Token", f"{uri_ui}?token={token}"),
        ("Base Path + Auth", f"{uri_base}?auth={token}"),
        ("UI Path + Auth", f"{uri_ui}?auth={token}"),
    ]

    for name, url in tests:
        print(f"Probando {name}...")
        try:
            async with websockets.connect(url, origin="https://maritime.sh") as ws:
                print(f"!!! EXITO con {name}")
                return
        except Exception as e:
            print(f"Fallo {name}: {e}")

if __name__ == "__main__":
    asyncio.run(test_origin())
