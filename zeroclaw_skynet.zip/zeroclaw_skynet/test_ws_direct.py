import asyncio
import websockets
import json

async def test_connection():
    uri = "wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui"
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    
    print("--- TESTING MARITIME WEBSOCKET ---")
    
    # Intento 1: Parámetros en URL
    try:
        print("\n[Intento 1] Query params (?token=)...")
        async with websockets.connect(f"{uri}?token={token}") as ws:
            print("CONECTADO!")
            resp = await asyncio.wait_for(ws.recv(), timeout=5)
            print(f"Respuesta: {resp}")
            return
    except Exception as e:
        print(f"Fallo 1: {e}")

    # Intento 2: Headers (esto no se puede en navegador pero sirve para descartar)
    try:
        print("\n[Intento 2] Headers (Authorization)...")
        headers = {"Authorization": f"Bearer {token}"}
        async with websockets.connect(uri, extra_headers=headers) as ws:
            print("CONECTADO!")
            resp = await asyncio.wait_for(ws.recv(), timeout=5)
            print(f"Respuesta: {resp}")
            return
    except Exception as e:
        print(f"Fallo 2: {e}")

    # Intento 3: Handshake por mensaje
    try:
        print("\n[Intento 3] Message Handshake...")
        async with websockets.connect(uri) as ws:
            print("Socket abierto, enviando auth...")
            await ws.send(json.dumps({"type": "auth", "token": token, "password": token}))
            resp = await asyncio.wait_for(ws.recv(), timeout=5)
            print(f"CONECTADO! Respuesta: {resp}")
            return
    except Exception as e:
        print(f"Fallo 3: {e}")

if __name__ == "__main__":
    asyncio.run(test_connection())
