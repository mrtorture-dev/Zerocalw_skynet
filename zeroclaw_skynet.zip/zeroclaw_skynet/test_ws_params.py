import asyncio
import websockets
import json

async def test_all_params():
    uri = "wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui"
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    params = ["auth", "key", "apiKey", "api_key", "access_token", "token"]
    
    for p in params:
        test_url = uri + "?" + p + "=" + token
        print("Probando " + p + "...")
        try:
            async with websockets.connect(test_url) as ws:
                print("!!! EXITO con ?" + p)
                return
        except Exception as e:
            print("Fallo " + p + ": " + str(e))

    print("\nProbando Basic Auth en URL...")
    try:
        basic_url = "wss://mrtorture-dev:" + token + "@maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui"
        async with websockets.connect(basic_url) as ws:
            print("!!! EXITO con Basic Auth")
            return
    except Exception as e:
        print("Fallo Basic Auth: " + str(e))

if __name__ == "__main__":
    asyncio.run(test_all_params())
