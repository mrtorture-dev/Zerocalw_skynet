import asyncio
import websockets
import json

async def test_maritime_session():
    # Nueva URL con el endpoint /ui/chat y el parámetro session sugerido
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    session = "agent:main"
    uri = f"wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui/chat?session={session}&token={token}"
    
    print(f"--- TESTING MARITIME SESSION CONNECTION ---")
    print(f"URL: {uri}")
    
    try:
        # Intentamos la conexión con la sesión especificada
        async with websockets.connect(uri) as ws:
            print("!!! EXITO: Conexión establecida con la sesión agent:main")
            print("Esperando primer mensaje del stream...")
            
            # Esperamos un mensaje para confirmar que el stream está vivo
            try:
                resp = await asyncio.wait_for(ws.recv(), timeout=10)
                print(f"MENSAJE RECIBIDO: {resp}")
            except asyncio.TimeoutError:
                print("Conectado, pero no se recibieron mensajes en 10 segundos (agente inactivo?)")
                
    except Exception as e:
        print(f"FALLO DE CONEXIÓN: {e}")

if __name__ == "__main__":
    asyncio.run(test_maritime_session())
