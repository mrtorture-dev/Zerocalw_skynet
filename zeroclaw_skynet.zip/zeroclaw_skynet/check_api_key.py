import asyncio
import aiohttp

async def check_api_key():
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    url = "https://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8"
    
    # Probamos diferentes formas de enviar la API Key
    methods = [
        {"Authorization": f"Bearer {token}"},
        {"x-api-key": token},
        {"api-key": token},
        {"Authorization": f"Basic {token}"}
    ]
    
    async with aiohttp.ClientSession() as session:
        for headers in methods:
            print(f"Probando con headers: {headers}")
            async with session.get(url, headers=headers) as resp:
                print(f"Status: {resp.status}")
                text = await resp.text()
                print(f"Response: {text[:50]}")

if __name__ == "__main__":
    asyncio.run(check_api_key())
