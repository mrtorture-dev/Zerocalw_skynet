import asyncio
import aiohttp

async def check_http():
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    # El endpoint de la UI a veces requiere una petición GET previa para establecer sesión
    url = f"https://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui/chat?session=agent:main&token={token}"
    
    async with aiohttp.ClientSession() as session:
        print(f"Probando GET a {url}")
        async with session.get(url, headers={"Origin": "https://maritime.sh"}) as resp:
            print(f"Status: {resp.status}")
            text = await resp.text()
            print(f"Body (primeros 100): {text[:100]}")

if __name__ == "__main__":
    asyncio.run(check_http())
