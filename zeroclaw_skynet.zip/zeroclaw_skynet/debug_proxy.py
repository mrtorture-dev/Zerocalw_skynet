import asyncio
import aiohttp
import json

async def debug_maritime():
    token = "k8EciDZXSk4lcUxC_yc3W11vE1sEdB5P"
    # Probamos la URL de CHAT directamente
    url = f"wss://maritime.sh/api/agents/c4a08fdc-49b4-4c14-a958-a289541e06d8/ui/chat?session=agent:main&token={token}"
    
    print(f"DEBUG: Intentando conectar a {url}")
    
    async with aiohttp.ClientSession() as session:
        headers = {
            "Origin": "https://maritime.sh",
            "User-Agent": "Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
        }
        try:
            async with session.ws_connect(url, headers=headers) as ws:
                print("!!! CONEXIÓN EXITOSA !!!")
                # Intentamos recibir algo
                msg = await ws.receive(timeout=5)
                print(f"Primer mensaje: {msg.data}")
        except Exception as e:
            print(f"ERROR FINAL: {e}")

if __name__ == "__main__":
    asyncio.run(debug_maritime())
