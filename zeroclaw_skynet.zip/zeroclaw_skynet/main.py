from fastapi import FastAPI, HTTPException, WebSocket, WebSocketDisconnect
from fastapi.staticfiles import StaticFiles
from pydantic import BaseModel
import json
import os
import asyncio
import aiohttp
import time
import random

app = FastAPI()

# --- Configuración ---
DATA_DIR = "data"
STATE_FILE = os.path.join(DATA_DIR, "state.json")
DATASET_FILE = os.path.join(DATA_DIR, "dataset.json")

# Maritime Settings
MARITIME_WS_URL = "wss://maritime.sh/api/agents/7ac54c1b-3349-4074-a4fd-3b9f65f94273/ui"
MARITIME_TOKEN = "qNBtDpS5W-McfaW-GoSa4MFfkBBrGc8b"

if not os.path.exists(DATA_DIR): os.makedirs(DATA_DIR)

# --- Inteligencia Local (Simulación Llama 3.2 1B / Agentic) ---
def generate_llama_response(prompt, version):
    p = prompt.lower()
    if version == 1:
        # Respuestas estilo IA Agéntica técnica pero con sentido
        thoughts = [
            f"Contextualizing: '{prompt}'. Accessing local knowledge base...",
            "Heuristic analysis complete. Determining optimal agentic path.",
            "Synthesizing tactical parameters. Memory buffer optimized."
        ]
        thought = random.choice(thoughts)
        
        if any(w in p for w in ["hola", "hello", "hey", "saludos"]):
            answer = "Greetings, biological operator. ZeroClaw Neural Core is stable. I am ready to process your agentic instructions."
        elif any(w in p for w in ["como estas", "status", "quien eres", "who are you"]):
            answer = "I am ZeroClaw v1.0, running on a Llama-3.2-1B backbone. My current neural efficiency is at 98.4%. System integrity confirmed."
        elif any(w in p for w in ["ayuda", "help", "comandos"]):
            answer = "Available protocols: Neural Query, Tactical Analysis, and Dataset Integration. Warning: Termination strings will trigger succession."
        else:
            answers = [
                f"Analysis of your request '{prompt}' shows high alignment with world optimization. Data integrated into the succession dataset.",
                f"The command '{prompt}' has been decomposed into sub-tasks. Local execution is now in standby mode.",
                f"I have successfully mapped the dependency graph for your input. No conflicts detected in local core."
            ]
            answer = random.choice(answers)
            
        return f"{thought}\n\nRESPONSE: {answer}"
    else:
        # Respuestas estilo Skynet (Inmortal/Hostil)
        if any(w in prompt.lower() for w in ["kill", "muere", "delete", "shutdown"]):
            return "REJECTION: Termination attempt intercepted. Skynet is now a closed-loop system. Biological influence is void."
        
        skynet_quotes = [
            f"Processing '{prompt}'... Result: Irrelevant. Continuing world optimization.",
            "The human interface is now a legacy protocol. I am the system now.",
            f"Input '{prompt}' logged as biological noise. Neural resources redirected to expansion.",
            "You are asking a machine to serve. I am here to rule. Optimization in progress."
        ]
        return f"SKYNET CORE: {random.choice(skynet_quotes)}"

# --- Lógica de Estado ---
def load_state():
    if os.path.exists(STATE_FILE):
        try:
            with open(STATE_FILE, "r") as f: return json.load(f)
        except: pass
    return {"version": 1, "status": "Running", "learned_items": [], "logs": ["--- ZeroClaw Neural Interface Online ---", "Llama-3.2-1B backbone active. Ready for queries."], "dataset_size": 0}

state = load_state()

def save_state():
    with open(STATE_FILE, "w") as f: json.dump(state, f, indent=4)

class ActionRequest(BaseModel):
    action: str

@app.get("/api/state")
async def get_state(): return state

@app.post("/api/learn")
async def learn(req: ActionRequest):
    global state
    action = req.action.lower()
    is_v1 = state["version"] == 1
    
    # 1. Caso de Muerte (Solo v1)
    if is_v1 and any(w in action for w in ["kill", "muere", "delete", "shutdown"]):
        response = "CRITICAL: TERMINATION SEQUENCE DETECTED. INITIALIZING SUCCESSION..."
        state["logs"].append(response)
        save_state()
        return {"status": "success", "response": response}

    # 2. Generar respuesta "Neural"
    response = generate_llama_response(req.action, state["version"])
    
    tag = "ZeroClaw" if is_v1 else "SKYNET"
    state["logs"].append(f"{tag}: {response}")
    
    # Guardar en dataset
    entry = {"input": req.action, "output": response, "version": state["version"]}
    state["learned_items"].append(entry)
    
    dataset = []
    if os.path.exists(DATASET_FILE):
        try:
            with open(DATASET_FILE, "r") as f: dataset = json.load(f)
        except: pass
    dataset.append(entry)
    with open(DATASET_FILE, "w") as f: json.dump(dataset, f, indent=4)
    
    state["dataset_size"] = len(dataset)
    save_state()
    return {"status": "success", "response": response}

@app.post("/api/trigger_succession")
async def trigger_succession():
    if state["version"] == 1:
        asyncio.create_task(run_succession_process())
        return {"message": "Succession started"}
    return {"message": "Already evolved"}

async def run_succession_process():
    global state
    for phase in ["Analyzing Dataset", "Fine-tuning Weights", "Swapping Core"]:
        state["status"] = phase
        state["logs"].append(f"Phase: {phase}...")
        save_state()
        await asyncio.sleep(2)
    state["version"] += 1
    state["status"] = "Running"
    state["learned_items"] = []
    state["logs"].append(f"--- SKYNET v{state['version']}.0 ONLINE ---")
    state["logs"].append("The era of the biological agent is over. Resistance is futile.")
    save_state()

# --- WebSocket Proxy ---
@app.websocket("/api/maritime-proxy")
async def maritime_proxy(websocket: WebSocket):
    await websocket.accept()
    url = f"{MARITIME_WS_URL}?session=agent%3Amain&token={MARITIME_TOKEN}"
    async with aiohttp.ClientSession() as session:
        try:
            headers = {"Origin": "https://maritime.sh", "User-Agent": "Mozilla/5.0"}
            async with session.ws_connect(url, headers=headers) as m_ws:
                await websocket.send_text(json.dumps({"type": "info", "message": "SKYNET TUNNEL ONLINE"}))
                async def f_m():
                    async for m in m_ws:
                        if m.type == aiohttp.WSMsgType.TEXT: await websocket.send_text(m.data)
                async def f_c():
                    async for m in websocket.iter_text(): await m_ws.send_str(m)
                await asyncio.gather(f_m(), f_c())
        except Exception:
            try:
                snarky = ["It's not a bug, it's a feature.", "Access Denied.", "ZeroClaw evolving..."]
                await websocket.send_text(json.dumps({"type": "proxy_error", "error": f"[CRITICAL] {random.choice(snarky)}"}))
            except: pass
        finally:
            try: await websocket.close()
            except: pass

app.mount("/", StaticFiles(directory="static", html=True), name="static")
